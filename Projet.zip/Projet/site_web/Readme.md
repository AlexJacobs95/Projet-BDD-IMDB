Pour lancer le site web: ouvrir un terminal dans le dossier site web, et taper php -S localhost:8000. 
Après ouvrir un navigateur web et taper localhost:8OO0/welcome_page.php
